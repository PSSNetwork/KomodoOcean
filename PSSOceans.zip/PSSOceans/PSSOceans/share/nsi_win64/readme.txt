Requirements:

- Internet client plug-in for files download and upload (http://nsis.sourceforge.net/Inetc_plug-in)
- Place komodo-qt-win.exe in content\komodo-qt-win.exe, before create installer

