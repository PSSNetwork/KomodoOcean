Daira Hopwood (3):
      Update pchMessageStart for mainnet and testnet.
      Update version numbers for 1.0.0-rc4.
      Add release notes for 1.0.0-rc4.

Jack Grigg (4):
      Integrate production Founders' Reward keys
      Remove Founders' Reward override from #1398
      Regenerate mainnet and testnet genesis blocks for nMaxTipAge change
      Update tests for new genesis blocks

Sean Bowe (1):
      Zcash zk-SNARK public parameters for 1.0 "Sprout".

