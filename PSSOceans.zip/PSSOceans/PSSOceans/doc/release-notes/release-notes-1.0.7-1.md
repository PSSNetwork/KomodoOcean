Jay Graber (3):
      Add -t to git fetch for release-notes.py
      Update version to 1.0.7-1
      Update auto-generated manpages to 1.0.7-1
